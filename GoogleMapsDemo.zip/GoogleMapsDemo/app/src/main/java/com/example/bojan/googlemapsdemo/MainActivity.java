package com.example.bojan.googlemapsdemo;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    MapFragment mapFragment;
    GoogleMap googleMap;
    LatLng demoLoacation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        demoLoacation = new LatLng(36.09095, 139.229811);


        mapFragment = (MapFragment)getFragmentManager().findFragmentById(R.id.map);//todo referenca MapFragmenta

        //todo Callback metoda koja ce se aktivirati kada mapa bude dostupna, potrebno je da joj se obezbedi paramatar OnMapReadyCallback implementirati interface
        mapFragment.getMapAsync(this);




    }
    //todo metoda interface OnMapReadyCallback
    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;


        //googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);//todo podesavanje tipa mape

        try {
            boolean success = googleMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.gmap_style));//todo postavljanje stila mape preko json file-a
            if (!success){
                Log.e("GMAP", "Style parsing faild");
            }

        }catch (Resources.NotFoundException e){
            Log.e("GMAP", "Can't file style. Error: "+ e);
        }
        //todo kreiranje custom ikonice flag-markera
        BitmapDrawable bitmapDrawable = (BitmapDrawable) getResources().getDrawable(R.drawable.flag);
        Bitmap flag = Bitmap.createScaledBitmap((Bitmap) bitmapDrawable.getBitmap(), 100,100, false);

        googleMap.addMarker(new MarkerOptions()
                .position(demoLoacation)
                .title("Hello World")
                .alpha(0.8f)
                .snippet("This is custom marker")
                .icon(BitmapDescriptorFactory.fromBitmap(flag)));
        // todo iscrtavanje linije po mapi pomocu tacaka lokacije
        PolylineOptions lineOption = new PolylineOptions();
        lineOption.add(new LatLng(44.81518, 20.30888))
                .add(new LatLng(45.63709, 21.64307))
                .add(new LatLng(45.63709, 23.02734))
                .add(new LatLng(44.75454, 26.20239))
                .add(new LatLng(41.54148, 31.20117))
                .add(new LatLng(38.30718, 29.66309))
                .add(new LatLng(37.8922, 24.47754))
                .add(new LatLng(37.93878, 23.95384));
        lineOption.color(Color.BLACK);
        lineOption.width(13f);
        googleMap.addPolyline(lineOption);
    }

    public void flyButtunonClick(View v){


        CameraPosition cameraPosition = new CameraPosition.Builder()//todo glavna klasa za definisanje osobina pogleda na mapi
                .target(demoLoacation) //lokacija kamere
                .zoom(17) //nivo priblizenja
                .bearing(90)//usmerenje
                .tilt(30)//ugao gledanja
                .build();//metoda koja isporucuje osobine kamere

        //todo animiranje camere
        googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition), 5000, null);

    }

}
